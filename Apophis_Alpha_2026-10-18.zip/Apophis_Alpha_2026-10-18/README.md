# Apophis — Alpha

**Alpha-Präsentationspaket · Stand 18.10.2026**

**Forschungsprototyp für nachvollziehbare Prüfungen synthetischer digitaler Identitäts- und Evidenzflüsse.**

Apophis untersucht, wie sich eine Testeingabe, die erwartete Entscheidung, das beobachtete Ergebnis und ein Integritätsnachweis reproduzierbar miteinander verknüpfen lassen. Die Beispiele sind für ein lokales, synthetisches Forschungslabor gedacht.

> **Reifegrad:** früher Forschungs- und Demonstrationsprototyp. Dieses Repository ist die öffentliche Präsentationsseite und Dokumentation; es enthält keinen ausführbaren Harness, keine Produktionssoftware und keine institutionelle Freigabe.

## Projektziele

- Digitale Identitäts- und Nachweisflüsse verständlich und lokal erforschbar machen.
- Prüfergebnisse mit künstlichen Daten reproduzierbar dokumentieren.
- Fragen zu Rollen, Datenminimierung, Integrität und Lieferkette als offene Forschungsfragen behandeln.
- Anwendungsprofile so beschreiben, dass Zweck, Annahmen und Grenzen klar bleiben.

Apophis ist kein kommerziell freigegebenes Produktversprechen. Ob ein Profil für eine konkrete Organisation passt, müssen deren fachliche, technische, Datenschutz- und Sicherheitsverantwortliche beurteilen.

## Öffentliche Projektseite

Die statische Präsentation liegt in [`index.html`](index.html). Sie ist ohne JavaScript-Framework und ohne externe Schrift- oder Skriptbibliotheken umgesetzt. Für lokale Vorschau kann im Repository-Verzeichnis ein statischer HTTP-Server gestartet werden:

```sh
python3 -m http.server 8000
```

Danach `http://127.0.0.1:8000/` im Browser öffnen. Der Server dient nur der lokalen Vorschau. Für GitHub Pages kann das Repository in **Settings → Pages** auf den `main`-Branch und das Repository-Wurzelverzeichnis eingestellt werden.

## Forschungs- und Anwendungsprofile

Die nachfolgenden Felder sind **mögliche Lern- und Forschungsrichtungen**, keine installierten Branchenlösungen, Kundenreferenzen oder Eignungsnachweise:

- **Verwaltung und E-ID:** synthetische Rollen, Nachweisabläufe, Datenminimierung und nachvollziehbare Entscheidungen.
- **Gesundheit und Versicherungen:** künstliche Berechtigungs- und Datenflussfälle; keine Versicherten- oder Gesundheitsdaten.
- **Forschung und Bildung:** reproduzierbare Experimente zu digitalen Nachweisen, Vertrauen und Reviewbarkeit.
- **Softwarelieferkette:** Fragen zu Herkunft, Abhängigkeiten, Prüfsummen und Zuständigkeiten. Ein Hash oder eine SBOM beweist für sich allein keine Sicherheit.
- **Finanzwesen und Versorgungsbetriebe:** denkbare spätere Profile ausschließlich mit synthetischen Daten und isolierten Testobjekten; keine echten Konten, Leitstellen, Netze oder OT/ICS-Systeme.
- **Verteidigung und militärische IT:** ausschließlich defensive, nicht-operative Forschungsfragen, etwa fiktive Rollen, Integrität synthetischer Übungsnachweise, abstrakte Resilienz-Tabletops und Lieferketten-/Freigabefragen.

### Verteidigungs- und Militärbezug: klare Bedingungen

Ein möglicher, rechtmäßiger Einsatz setzt mindestens einen dokumentierten Zweck, die ausdrückliche schriftliche Autorisierung der zuständigen Systemverantwortlichen, einen eng begrenzten Scope, genehmigte Methoden, Zeitfenster, Abbruchkontakt und passende interne Datenschutz- und Sicherheitsfreigaben voraus. Je nach System und Informationen können weitere rechtliche und institutionelle Erlaubnisse nötig sein; diese müssen vorab von den zuständigen Stellen geklärt werden.

Die öffentliche Apophis-Präsentation beschreibt keine operativen militärischen Fähigkeiten. Sie bietet oder dokumentiert insbesondere keine Angriffe, Ausnutzung, Zielauswahl, Erkundung, Umgehung, Persistenz oder Störung realer Systeme. Keine echten militärischen Führungs-, Einsatz-, Waffen-, Sensor-, Kommunikations- oder Logistiksysteme testen; keine klassifizierten oder nicht öffentlichen Informationen, Zugangsdaten oder realen Netzdaten in öffentliche Beispiele einbringen. Ein öffentlicher Anwendungsfall ist niemals eine Erlaubnis.

Apophis ist keine Bundeswehr- oder NATO-Veröffentlichung, kein offiziell geprüftes Werkzeug und keine Zulassung, Zertifizierung oder Sicherheitsfreigabe.

## Sicherer Ablauf für jede reale Prüfung

1. **Auftrag und Verantwortliche benennen:** Wer besitzt das System und darf den Test genehmigen?
2. **Schriftliche Freigabe und Scope festhalten:** genaue Ziele, Zeitfenster, Methoden, Daten, Kontakt und Abbruchregeln.
3. **Risiken und Daten minimieren:** zunächst synthetische oder ausdrücklich freigegebene Testdaten in einer isolierten Umgebung verwenden.
4. **Nicht-destruktiv beginnen:** nur vorab genehmigte Prüfschritte durchführen; keine eigenmächtige Erweiterung des Scopes.
5. **Ergebnisse verantwortungsvoll behandeln:** Befunde nur den benannten Stellen übermitteln und Aufbewahrung/Löschung vereinbaren.

Diese Liste ist eine allgemeine Orientierung und keine Rechtsberatung oder vollständige Sicherheitsrichtlinie. Rechtliche Zulässigkeit und interne Vorgaben müssen für jeden konkreten Auftrag durch die zuständigen Stellen geprüft werden.

## Tests und Reifegrad

Dieses Repository enthält nur die Projektseite und Dokumentation. Es führt keine Tests des Apophis-Harness aus und die Website behauptet keine aktuelle Testabdeckung. In einem früheren Lauf des separaten Forschungs-Harness wurden 97 Pytest-Fälle und 97 Unittest-Fälle bestanden; außerdem wurden ein synthetischer Last-/Grenzwertlauf mit 2.000 zurückgewiesenen Eingaben und eine lokale Drei-Fall-Demo dokumentiert. Diese historischen Angaben sind keine unabhängige Sicherheitsprüfung und belegen nicht den Zustand dieser Website oder eines späteren Harness-Releases. Vor einer technischen Nutzung muss der konkrete Quellstand frisch geprüft und mit seiner Prüfsumme eindeutig identifiziert werden.

Nicht behauptet werden: Penetrationstest, unabhängiger Audit, Fuzzing-Zertifizierung, formale Verifikation, Konformität, Produktionsreife oder Freigabe durch eine Behörde, OSBA, Bundeswehr, NATO, Krankenkasse oder sonstige Organisation.

## Integrität, Releases und Hashes

Ein SHA-256-Wert ist nur dann hilfreich, wenn klar ist, **welche konkrete Datei oder welches Release** er bezeichnet und der Wert über einen unabhängigen Kanal verglichen werden kann. Diese Präsentationsseite bietet derzeit kein herunterladbares Software-Release; daher wird hier kein Hash als vermeintlicher Sicherheitsnachweis angegeben. Bei künftigen Quellarchiven sollten Release-Tag, Archiv, SBOM und Prüfsumme zusammen veröffentlicht werden. Ein Hash bestätigt Übereinstimmung mit einem bekannten Byte-Stand, nicht Herkunft, Unbedenklichkeit oder Sicherheit.

## Lizenz und Rechte

Apophis-Präsentationsmaterial in diesem Repository wird unter der **Apache License 2.0** veröffentlicht. Siehe [`LICENSE`](LICENSE). Copyright-Angabe: © 2026 Kai Valenta. Drittanbieter-Materialien behalten gegebenenfalls ihre eigenen Lizenzbedingungen.

Apache 2.0 erlaubt Nutzung, Änderung und Weitergabe unter den Lizenzbedingungen. Sie gewährt keine Exklusivität an einem Vertriebspartner. Projektname und Kennzeichen sind nicht automatisch durch die Softwarelizenz zur beliebigen Markenverwendung freigegeben.

## Beiträge

Vorschläge und sachliche Fehlerhinweise sind willkommen. Bitte keine echten Personen-, Gesundheits-, Behörden-, Militär- oder Zugangsdaten, internen Dokumente, nicht öffentlichen Findings oder Geheimnisse in Issues oder Pull Requests einstellen. Für eine verantwortungsvolle Sicherheitsmeldung bitte zunächst den Projektkontakt nutzen und keine sensiblen Details öffentlich veröffentlichen.

## Kontakt

**Kai Valenta** — Projektkontakt; Rechteinhaber laut Projektangabe  
E-Mail: [kava1982@gmail.com](mailto:kava1982@gmail.com)

## Status in einem Satz

Apophis ist ein unabhängiges, frühes Forschungsprojekt für synthetische, lokal nachvollziehbare Identitäts- und Evidenzszenarien — kein einsatzbereites Prüfprodukt und keine institutionelle Empfehlung.
